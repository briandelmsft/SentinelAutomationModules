from classes import BaseModule, Response, DeviceExposureModule
from shared import rest, data
import json
import logging

def execute_device_exposure_module (req_body):

    # Log module invocation with parameters (excluding BaseModuleBody)
    log_params = {k: v for k, v in req_body.items() if k != 'BaseModuleBody'}
    logging.info(f'Device Exposure Module invoked with parameters: {log_params}')

    #Inputs AddIncidentComments, AddIncidentTask, BaseModuleBody, IncidentTaskInstructions, AddIncidentTags

    base_object = BaseModule()
    base_object.load_from_input(req_body['BaseModuleBody'])
    lookback = req_body.get('LookbackInDays', 14)
    exp_object = DeviceExposureModule()

    mde_ids = base_object.get_host_mdeid_list()

    if mde_ids:
        exp_object.AnalyzedEntities = len(mde_ids)
        query = data.load_text_from_file('exposure-device.kql', mde_id_list=mde_ids)
        response = rest.execute_m365d_query(base_object, query)

        exp_object.Nodes = list(filter(lambda x: x['NodeType'] == 'Node', response))
        exp_object.Paths = list(filter(lambda x: x['NodeType'] == 'Path', response))

    if req_body.get('AddIncidentComments', True) and base_object.IncidentAvailable:
        add_comment_to_incident(base_object, exp_object)

    if req_body.get('AddIncidentTags', True) and base_object.IncidentAvailable:
        add_tags_to_incident(base_object, exp_object)

    if req_body.get('AddIncidentTask', False) and len(exp_object.Nodes) > 0 and base_object.IncidentAvailable:
        rest.add_incident_task(base_object, 'Review Device Exposure Information', data.coalesce(req_body.get('IncidentTaskInstructions'), 'Review the output of the Device Exposure Module in the incident comments.'))

    return Response(exp_object)


def add_tags_to_incident (base_object, exp_object):
    tags = []
    for x in exp_object.Nodes:
        if x['ComputerCriticalityRules']:
            tags += x['ComputerCriticalityRules']
    rest.add_incident_tags(base_object, tags)

def add_comment_to_incident (base_object, exp_object):
    crit_level = {
        0: 'Very High 🟥🟥🟥🟥',
        1: 'High 🟥🟥🟥⬜ ',
        2: 'Medium 🟥🟥⬜⬜',
        3: 'Low 🟥⬜⬜⬜'
    }

    out = []

    for x in exp_object.Paths:

        sid = None
        entra_sid = None
        aadid = None

        for acct_id in x.get('UserEntityIds', []):
            if acct_id['type'] == 'SecurityIdentifier':
                if acct_id.get('id').startswith('S-1-12-'):
                    entra_sid = acct_id['id']
                else:
                    sid = acct_id['id']
            elif acct_id['type'] == 'AadObjectId':
                aadid = data.parse_kv_string(acct_id['id']).get('objectid')

        if aadid:
            user_on_device = f"<a href=\"https://security.microsoft.com/user?aad={aadid}&tab=overview\" target=\"_blank\">{x['UsersOnDevice']}</a>"
        elif sid:
            user_on_device = f"<a href=\"https://security.microsoft.com/user?sid={sid}&tab=overview\" target=\"_blank\">{x['UsersOnDevice']}</a>"
        else:
            user_on_device = x['UsersOnDevice']

        if x['UserNodeLabel'] == 'managedidentity':
            user_on_device += f"<p>(Managed Identity)"

        out.append({
            'Computer': get_device_link(x),
            'Computer Details': f"<b>Criticality:</b><p> {crit_level[x['ComputerCrit']]}<p><b>Asset Rules:</b> {data.list_to_string(x['ComputerCriticalityRules'])}<p><b>Computer Tags:</b> {data.list_to_string(x['ComputerTags'])}<p><b>Risk Level:</b> {x['ComputerRiskScore']}<p><b>Exposure Level:</b> {x['ComputerExposureScore']}<p><b>Max CVSS Score:</b> {x['ComputerMaxCVSSScore']}<p><b>Onboarding:</b> {x['ComputerOnboarding']}<p><b>Sensor:</b> {x['ComputerSensorHealth']}",
            'UsersOnDevice': user_on_device,
            'UserCriticality': f"{crit_level[x['UserCrit']]}<p><b>Asset Rules:</b> {data.list_to_string(x['UserCriticalityRules'])}<p><b>User Tags:</b> {data.list_to_string(x['UserTags'])}"
        })

    for x in exp_object.nodes_without_paths():
        out.append({
            'Computer': get_device_link(x),
            'Computer Details': f"<b>Criticality:</b><p> {crit_level[x['ComputerCrit']]}<p><b>Asset Rules:</b> {data.list_to_string(x['ComputerCriticalityRules'])}<p><b>Computer Tags:</b> {data.list_to_string(x['ComputerTags'])}<p><b>Risk Level:</b> {x['ComputerRiskScore']}<p><b>Exposure Level:</b> {x['ComputerExposureScore']}<p><b>Max CVSS Score:</b> {x['ComputerMaxCVSSScore']}<p><b>Onboarding:</b> {x['ComputerOnboarding']}<p><b>Sensor:</b> {x['ComputerSensorHealth']}",
            'UsersOnDevice': "None Detected"
        })

    comment = f'<h3>Device Exposure Module</h3>'
    if out:
        html_table = data.list_to_html_table(out, index=False, max_cols=20, escape_html=False)
        comment += html_table
    else:
        comment += f'No Device Exposure Results Detected'
    
    comment_result = rest.add_incident_comment(base_object, comment)

def get_device_link(x):
    device_id = None
    for dev_id in x.get('ComputerEntityIds', []):
        if dev_id['type'] == 'DeviceInventoryId':
            device_id = dev_id['id']
            break

    if device_id:
        return f"<a href=\"https://security.microsoft.com/machines/v2/{device_id}/overview\" target=\"_blank\">{x['Computer']}</a><p>(<a href=\"https://security.microsoft.com/security-graph?id={device_id}&assetType=DeviceInventoryId\">Exposure Map</a>)"
    else:
        return x['Computer']